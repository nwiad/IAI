#include <iostream>
#include <unistd.h>
#include "Point.h"
#include "Strategy.h"
#include "Judge.h"

using namespace std;

#define INF 46340
#define MAX_DEPTH 4
void count(const int M, const int N, int** board, const int noX, const int noY);
/*
	策略函数接口,该函数被对抗平台调用,每次传入当前状态,要求输出你的落子点,该落子点必须是一个符合游戏规则的落子点,不然对抗平台会直接认为你的程序有误
	
	input:
		为了防止对对抗平台维护的数据造成更改，所有传入的参数均为const属性
		M, N : 棋盘大小 M - 行数 N - 列数 均从0开始计， 左上角为坐标原点，行用x标记，列用y标记
		top : 当前棋盘每一列列顶的实际位置. e.g. 第i列为空,则_top[i] == M, 第i列已满,则_top[i] == 0
		_board : 棋盘的一维数组表示, 为了方便使用，在该函数刚开始处，我们已经将其转化为了二维数组board
				你只需直接使用board即可，左上角为坐标原点，数组从[0][0]开始计(不是[1][1])
				board[x][y]表示第x行、第y列的点(从0开始计)
				board[x][y] == 0/1/2 分别对应(x,y)处 无落子/有用户的子/有程序的子,不可落子点处的值也为0
		lastX, lastY : 对方上一次落子的位置, 你可能不需要该参数，也可能需要的不仅仅是对方一步的
				落子位置，这时你可以在自己的程序中记录对方连续多步的落子位置，这完全取决于你自己的策略
		noX, noY : 棋盘上的不可落子点(注:涫嫡饫锔?龅膖op已经替你处理了不可落子点，也就是说如果某一步
				所落的子的上面恰是不可落子点，那么UI工程中的代码就已经将该列的top值又进行了一次减一操作，
				所以在你的代码中也可以根本不使用noX和noY这两个参数，完全认为top数组就是当前每列的顶部即可,
				当然如果你想使用lastX,lastY参数，有可能就要同时考虑noX和noY了)
		以上参数实际上包含了当前状态(M N _top _board)以及历史信息(lastX lastY),你要做的就是在这些信息下给出尽可能明智的落子点
	output:
		你的落子点Point
*/
extern "C" Point* getPoint(const int M, const int N, const int* top, const int* _board, 
	const int lastX, const int lastY, const int noX, const int noY){
	/*
		不要更改这段代码
	*/
	int x = -1, y = -1;//最终将你的落子点存到x,y中
	int** board = new int*[M];
	for(int i = 0; i < M; i++){
		board[i] = new int[N];
		for(int j = 0; j < N; j++){
			board[i][j] = _board[i * N + j];
		}
	}
	
	/*
		根据你自己的策略来返回落子点,也就是根据你的策略完成对x,y的赋值
		该部分对参数使用没有限制，为了方便实现，你可以定义自己新的类、.h文件、.cpp文件
	*/
    
//    count(M, N, board, noX, noY);
    
    int *Top = new int[N];
    int maxVal = -INF * INF;
    for(int i = N - 1; i >= 0; i--) {
        if(top[i] > 0) {
            int candX = top[i] - 1;
            int candY = i;
            board[candX][candY] = 2;
            if(machineWin(candX, candY, M, N, board)) {
                x = candX;
                y = candY;
                return new Point(x, y);
            }
            board[candX][candY] = 1;
            if(userWin(candX, candY, M, N, board)) {
                x = candX;
                y = candY;
                return new Point(x, y);
            }
            board[candX][candY] = 0;
        }
    }
    for(int i = N - 1; i >= 0; i--) {
        for(int j = 0; j < N; j++) {
            Top[j] = top[j];
        }
        if(top[i] > 0) {
            int candX = top[i] - 1;
            int candY = i;
//            board[candX][candY] = 2;
//            if(machineWin(candX, candY, M, N, board)) {
//                x = candX;
//                y = candY;
//                break;
//            }
//            board[candX][candY] = 1;
//            if(userWin(candX, candY, M, N, board)) {
//                x = candX;
//                y = candY;
//                break;
//            }
            board[candX][candY] = 2;
            Top[i]--;
            int val = searchMax(M, N, board, Top, 1, -INF * INF, INF * INF, noX, noY);
            if(val > maxVal) {
                x = candX;
                y = candY;
            }
            board[candX][candY] = 0;
        }
    }
    delete[] Top;
	/*
		不要更改这段代码
	*/
	clearArray(M, N, board);
	return new Point(x, y);
}


/*
	getPoint函数返回的Point指针是在本dll模块中声明的，为避免产生堆错误，应在外部调用本dll中的
	函数来释放空间，而不应该在外部直接delete
*/
extern "C" void clearPoint(Point* p){
	delete p;
	return;
}

/*
	清除top和board数组
*/
void clearArray(int M, int N, int** board){
	for(int i = 0; i < M; i++){
		delete[] board[i];
	}
	delete[] board;
}


/*
	添加你自己的辅助函数，你可以声明自己的类、函数，添加新的.h .cpp文件来辅助实现你的想法
*/

int searchMax(const int M, const int N, int **board, int *Top, int depth, int alpha, int beta, const int noX, const int noY) {
	if(depth >= MAX_DEPTH) return evaluateBoard(M, N, board, noX, noY);
	int maxVal = -INF * INF;
	for(int y = N - 1; y >= 0; y--) {
		int x = Top[y] - 1;
		if(x == -1) continue;
        if(x == noX && y == noY) {
            if(x == 0) {
                Top[y]--;
                continue;
            }
            x--;
            Top[y] -= 2;
        }
        else {
            Top[y]--;
        }
        
		board[x][y] = 2;
		if(machineWin(x, y, M, N, board)) {
            Top[y]++;
			board[x][y] = 0;
			return 1000 * INF * (1 + MAX_DEPTH - depth);
		}
        board[x][y] = 1;
        if(userWin(x, y, M, N, board)) {
            Top[y]++;
            board[x][y] = 0;
            return -INF * INF;
        }
        
        board[x][y] = 2;
		int val = searchMin(M, N, board, Top, depth + 1, max(alpha, maxVal), beta, noX, noY);
        Top[y]++;
        board[x][y] = 0;
		if(val > maxVal) {
			maxVal = val;
			if(maxVal >= beta) return maxVal;
		}
	}
	return maxVal;
}

int searchMin(const int M, const int N, int **board, int *Top, int depth, int alpha, int beta, const int noX, const int noY) {
	if(depth >= MAX_DEPTH) return evaluateBoard(M, N, board, noX, noY);
	int minVal = INF * INF;
	for(int y = 0; y < N; y++) {
		int x = Top[y] - 1;
		if(x == -1) continue;
        if(x == noX && y == noY) {
            if(x == 0) {
                Top[y]--;
                continue;
            }
            x--;
            Top[y] -= 2;
        }
        else {
            Top[y]--;
        }
        
		board[x][y] = 1;
		if(userWin(x, y, M, N, board)) {
            Top[y]++;
			board[x][y] = 0;
			return - 1000 * INF * (1 + MAX_DEPTH - depth);
		}
        board[x][y] = 2;
        if(machineWin(x, y, M, N, board)) {
            Top[y]++;
            board[x][y] = 0;
            return INF * INF;
        }
        
        board[x][y] = 1;
		int val = searchMax(M, N, board, Top, depth + 1, alpha, min(minVal, beta), noX, noY);
        Top[y]++;
        board[x][y] = 0;
		if(val < minVal) {
			minVal = val;
			if(minVal <= alpha) return minVal;
		}
	}
	return minVal;
}

bool effectiveX(const int M, int **board, int pred, int count, int i, int j, const int noX, const int noY) {
    if(pred == 0 || count < 2) return false;
    if(i == M || board[i][j] > 0 || (i == noX && j == noY)) {
        if(i-count-1 < 0 || board[i-count-1][j] > 0 || (i-count-1 == noX && j == noY)) return false;
    }
    return true;
}

bool effectiveY(const int N, int **board, int pred, int count, int i, int j, const int noX, const int noY) {
    if(pred == 0 || count < 2) return false;
    if(j == N || board[i][j] > 0 || (i == noX && j == noY)) {
        if(j-count-1 < 0 || board[i][j-count-1] > 0 || (i == noX && j-count-1 == noY)) return false;
    }
    return true;
}

bool effectiveDiag(const int M, const int N, int **board, int pred, int count, int i, int j, const int noX, const int noY) {
    if(pred == 0 || count < 2) return false;
    if(i == M || j == N || board[i][j] > 0 || (i == noX && j == noY)) {
        if(i-count-1 < 0 || j-count-1 < 0 || board[i-count-1][j-count-1] > 0 || (i-count-1 == noX && j-count-1 == noY)) return false;
    }
    return true;
}

bool effectiveClinoDiag(const int M, const int N, int **board, int pred, int count, int i, int j, const int noX, const int noY) {
    if(pred == 0 || count < 2) return false;
    if(i == M || j == N || board[i][j] > 0 || (i == noX && j == noY)) {
        if(i-count-1 < 0 || j+count+1 >= N || board[i-count-1][j+count+1] > 0 || (i-count-1 == noX && j+count+1 == noY)) return false;
    }
    return true;
}

int evaluateBoard(const int M, const int N, int** board, const int noX, const int noY) {
//    return 1000;
//    cerr << "start counting\n";
	int score = 0;  // 最终评分
	int humanWeight = -100, robotWeight = 100;  // 权重
	// 搜寻纵向（x方向）的连子
	for(int j = 0; j < N; j++) {
		int count = 1;  // 连子的数量  
		int pred = board[0][j];  // 上一个子的种类 0/1/2
//        cerr << "top: " << pred << '\n';
		for(int i = 1; i < M; i++) {
			if(board[i][j] == pred) {  // 出现连子？
				if(pred > 0) count += 1;  // 有子
				// 无子，pred自然保持为0，无需特殊处理
			}
			else {  // 不再连续排布，处理之前的连子
                if(effectiveX(M, board, pred, count, i, j, noX, noY)) {
                    score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
//                    cerr << "x: " << "(" << i << "," << j << ") "<< count << '\n';
                }
				pred = board[i][j];
//                cerr << "change pred: " << pred << '\n';
				count = 1;
			}
		}
        if(effectiveX(M, board, pred, count, M, j, noX, noY)) {
            score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
//            cerr << "x: " << "(" << M << "," << j << ") "<< count << '\n';
        }
	}
	// 搜寻横向（y方向）的连子
	for(int i = 0; i < M; i++) {
		int count = 1;
		int pred = board[i][0];
		for (int j = 1; j < N; j++) {
			if(board[i][j] == pred) {
				if(pred > 0) count += 1;
			}
			else {
				if(effectiveY(N, board, pred, count, i, j, noX, noY)) score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
				pred = board[i][j];
				count = 1;
			}
		}
        if(effectiveY(N, board, pred, count, i, N, noX, noY)) {
            score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
        }
	}
	// 搜寻左上-右下的连子
	// i = 0
	for(int j = 0; j < N; j++) {
		int count = 1;
		int pred = board[0][j];
        int mark = -1;
		for(int k = 1; k + j < N && k < M; k++) {
            mark = k;
			if(board[k][k + j] == pred) {
				if(pred > 0) count += 1;
			}
			else {
				if(effectiveDiag(M, N, board, pred, count, k, k+j, noX, noY)) score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
				pred = board[k][k + j];
				count = 1;
			}
		}
        if(effectiveDiag(M, N, board, pred, count, mark+1, mark+1+j, noX, noY)) {
            score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
        }
	}
	// i ≥ 1
	for(int i = 1; i < M; i++) {
		int count = 1;
		int pred = board[i][0];
        int mark = -1;
		for(int k = 1; k + i < M && k < N; k++) {
            mark = k;
			if(board[i + k][k] == pred) {
				if(pred > 0) count += 1;
			}
			else {
				if(effectiveDiag(M, N, board, pred, count, i+k, k, noX, noY)) score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
				pred = board[i + k][k];
				count = 1;	
			}
		}
        if(effectiveDiag(M, N, board, pred, count, i+mark+1, mark+1, noX, noY)) {
            score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
        }
	}
	// 搜寻右上-左下的连子
	// i = 0 
	for(int j = 0; j < N; j++) {
		int count = 1;
		int pred = board[0][j];
        int mark = -1;
		for(int k = 1; j - k >= 0 && k < M; k++) {
            mark = k;
			if(board[k][j - k] == pred) {
				if(pred > 0) count += 1;
			}
			else {
				if(effectiveClinoDiag(M, N, board, pred, count, k, j-k, noX, noY)) score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
				pred = board[k][j - k];
				count = 1;
			}
		}
        if(effectiveClinoDiag(M, N, board, pred, count, mark+1, j-mark-1, noX, noY)) {
            score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
        }
	}
	// i ≥ 1
	for(int i = 1; i < M; i++) {
		int count = 1;
		int pred = board[i][N - 1];
        int mark = -1;
		for(int k = 1; k + i < M && k < N; k++) {
            mark = k;
			if(board[i + k][N - 1 - k] == pred) {
				if(pred > 0) count += 1;
			}
			else {
				if(effectiveClinoDiag(M, N, board, pred, count, i+k, N-1-k, noX, noY)) score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
				pred = board[i + k][N - 1 - k];
				count = 1;
			}
		}
        if(effectiveClinoDiag(M, N, board, pred, count, i+mark+1, N-1-mark-1, noX, noY)) {
            score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
        }
	}
	return score;
}

void count(const int M, const int N, int** board, const int noX, const int noY) {
//    return 1000;
    cerr << "start counting\n";
    int score = 0;  // 最终评分
    int humanWeight = -100, robotWeight = 100;  // 权重
    // 搜寻纵向（x方向）的连子
    for(int j = 0; j < N; j++) {
        int count = 1;  // 连子的数量
        int pred = board[0][j];  // 上一个子的种类 0/1/2
        cerr << "top: " << pred << '\n';
        for(int i = 1; i < M; i++) {
            if(board[i][j] == pred) {  // 出现连子？
                if(pred > 0) count += 1;  // 有子
                // 无子，pred自然保持为0，无需特殊处理
            }
            else {  // 不再连续排布，处理之前的连子
                if(effectiveX(M, board, pred, count, i, j, noX, noY)) {
                    score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
                    cerr << "x: " << "(" << i << "," << j << ") "<< count << '\n';
                }
                pred = board[i][j];
//                cerr << "change pred: " << pred << '\n';
                count = 1;
            }
        }
        if(effectiveX(M, board, pred, count, M, j, noX, noY)) {
            score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
            cerr << "x: " << "(" << M << "," << j << ") "<< count << '\n';
        }
    }
    
    // 搜寻横向（y方向）的连子
    for(int i = 0; i < M; i++) {
        int count = 1;
        int pred = board[i][0];
        for (int j = 1; j < N; j++) {
            if(board[i][j] == pred) {
                if(pred > 0) count += 1;
            }
            else {
                if(effectiveY(N, board, pred, count, i, j, noX, noY)) {
                    score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
                    cerr << "y: " << "(" << i << "," << j << ") "<< count << '\n';
                }
                pred = board[i][j];
                count = 1;
            }
        }
        if(effectiveY(N, board, pred, count, i, N, noX, noY)) {
            score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
            cerr << "y: " << "(" << i << "," << N << ") "<< count << '\n';
        }
    }
    // 搜寻左上-右下的连子
    // i = 0
    for(int j = 0; j < N; j++) {
        int count = 1;
        int pred = board[0][j];
        int mark = -1;
        for(int k = 1; k + j < N && k < M; k++) {
            mark = k;
            if(board[k][k + j] == pred) {
                if(pred > 0) count += 1;
            }
            else {
                if(effectiveDiag(M, N, board, pred, count, k, k+j, noX, noY)) {
                    score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
                    cerr << "diag: " << "(" << k << "," << k+j << ") "<< count << '\n';
                }
                pred = board[k][k + j];
                count = 1;
            }
        }
        if(effectiveDiag(M, N, board, pred, count, mark+1, mark+1+j, noX, noY)) {
            score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
            cerr << "diag: " << "(" << mark+1 << "," << mark+1+j << ") "<< count << '\n';
        }
    }
    // i ≥ 1
    for(int i = 1; i < M; i++) {
        int count = 1;
        int pred = board[i][0];
        int mark = -1;
        for(int k = 1; k + i < M && k < N; k++) {
            mark = k;
            if(board[i + k][k] == pred) {
                if(pred > 0) count += 1;
            }
            else {
                if(effectiveDiag(M, N, board, pred, count, i+k, k, noX, noY)) {
                    score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
                    cerr << "diag: " << "(" << i+k << "," << k << ") "<< count << '\n';
                }
                pred = board[i + k][k];
                count = 1;
            }
        }
        if(effectiveDiag(M, N, board, pred, count, i+mark+1, mark+1, noX, noY)) {
            score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
            cerr << "diag: " << "(" << i+mark+1 << "," << mark+1 << ") "<< count << '\n';
        }
    }
    // 搜寻右上-左下的连子
    // i = 0
    for(int j = 0; j < N; j++) {
        int count = 1;
        int pred = board[0][j];
        int mark = -1;
        for(int k = 1; j - k >= 0 && k < M; k++) {
            mark = k;
            if(board[k][j - k] == pred) {
                if(pred > 0) count += 1;
            }
            else {
                if(effectiveClinoDiag(M, N, board, pred, count, k, j-k, noX, noY)) score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
                pred = board[k][j - k];
                count = 1;
            }
        }
        if(effectiveClinoDiag(M, N, board, pred, count, mark+1, j-mark-1, noX, noY)) {
            score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
        }
    }
    // i ≥ 1
    for(int i = 1; i < M; i++) {
        int count = 1;
        int pred = board[i][N - 1];
        int mark = -1;
        for(int k = 1; k + i < M && k < N; k++) {
            mark = k;
            if(board[i + k][N - 1 - k] == pred) {
                if(pred > 0) count += 1;
            }
            else {
                if(effectiveClinoDiag(M, N, board, pred, count, i+k, N-1-k, noX, noY)) score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
                pred = board[i + k][N - 1 - k];
                count = 1;
            }
        }
        if(effectiveClinoDiag(M, N, board, pred, count, i+mark+1, N-1-mark-1, noX, noY)) {
            score += (pred == 1) ? humanWeight * count * count : robotWeight * count * count;
        }
    }
}
